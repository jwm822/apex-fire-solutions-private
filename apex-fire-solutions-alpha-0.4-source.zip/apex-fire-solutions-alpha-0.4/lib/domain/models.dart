enum VerificationStatus { predicted, reference, fieldVerified, truedPrediction }
enum DragModelKind { g1, g7, custom }
enum AngularUnit { moa, mil }
enum MvSource { manual, chronograph, interpolatedTemp, extrapolatedTemp }

class Projectile {
  final String name;
  final double weightGr;
  final double diameterIn;
  final double lengthIn;
  final DragModelKind dragModel;
  final double? ballisticCoefficient;
  const Projectile({required this.name, required this.weightGr, required this.diameterIn, required this.lengthIn, required this.dragModel, this.ballisticCoefficient});
}

class MvTempPoint {
  final double temperatureF;
  final double velocityFps;
  const MvTempPoint({required this.temperatureF, required this.velocityFps});
}

class Environment {
  final double temperatureF;
  final double stationPressureInHg;
  final double humidityPct;
  final double altitudeFt;
  const Environment({required this.temperatureF, required this.stationPressureInHg, required this.humidityPct, required this.altitudeFt});
}

class RifleProfile {
  final String id;
  final String name;
  final Projectile projectile;
  final double muzzleVelocityFps;
  final MvSource mvSource;
  final double zeroYd;
  final double sightHeightIn;
  final double barrelLengthIn;
  final double twistIn;
  final bool rightHandTwist;
  final AngularUnit angularUnit;
  final List<MvTempPoint> mvTemp;
  const RifleProfile({required this.id, required this.name, required this.projectile, required this.muzzleVelocityFps, required this.mvSource, required this.zeroYd, required this.sightHeightIn, required this.barrelLengthIn, required this.twistIn, required this.rightHandTwist, required this.angularUnit, this.mvTemp = const []});
}

class FieldObservation {
  final String id;
  final String profileId;
  final double rangeYd;
  final double actualElevation;
  final AngularUnit unit;
  final DateTime observedAt;
  final String? notes;
  const FieldObservation({required this.id, required this.profileId, required this.rangeYd, required this.actualElevation, required this.unit, required this.observedAt, this.notes});
}

class ValidationCourse {
  final String name;
  final List<double> rangesYd;
  const ValidationCourse({required this.name, required this.rangesYd});
}
