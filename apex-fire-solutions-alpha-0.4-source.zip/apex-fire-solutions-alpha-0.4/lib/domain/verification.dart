import 'models.dart';
import '../ballistics/engine.dart';

class ComparedPoint {
  final double rangeYd;
  final BallisticPoint? prediction;
  final double? referenceElevation;
  final FieldObservation? field;
  const ComparedPoint({required this.rangeYd, this.prediction, this.referenceElevation, this.field});

  double? get predictionVsFieldDelta => prediction == null || field == null ? null : prediction!.elevation - field!.actualElevation;
  double? get predictionVsReferenceDelta => prediction == null || referenceElevation == null ? null : prediction!.elevation - referenceElevation!;
}
