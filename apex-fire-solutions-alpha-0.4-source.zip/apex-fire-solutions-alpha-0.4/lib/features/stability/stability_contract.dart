import '../../domain/models.dart';

class StabilityRequest {
  final Projectile projectile;
  final double muzzleVelocityFps;
  final double twistIn;
  final Environment environment;
  const StabilityRequest({required this.projectile, required this.muzzleVelocityFps, required this.twistIn, required this.environment});
}

class StabilityResult {
  final double sg;
  final String method;
  const StabilityResult({required this.sg, required this.method});
}

abstract interface class StabilityCalculator {
  StabilityResult calculate(StabilityRequest request);
}
