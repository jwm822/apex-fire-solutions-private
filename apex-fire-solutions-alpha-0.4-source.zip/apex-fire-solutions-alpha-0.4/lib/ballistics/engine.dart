import '../domain/models.dart';

class BallisticRequest {
  final RifleProfile profile;
  final Environment environment;
  final List<double> rangesYd;
  final double windMph;
  final double windDirectionDeg;
  final double shotAngleDeg;
  final double? azimuthDeg;
  final double? latitudeDeg;
  const BallisticRequest({required this.profile, required this.environment, required this.rangesYd, this.windMph = 0, this.windDirectionDeg = 0, this.shotAngleDeg = 0, this.azimuthDeg, this.latitudeDeg});
}

class BallisticPoint {
  final double rangeYd;
  final double elevation;
  final double wind;
  final AngularUnit unit;
  final double velocityFps;
  final double energyFtLb;
  final double timeOfFlightSec;
  final double mach;
  const BallisticPoint({required this.rangeYd, required this.elevation, required this.wind, required this.unit, required this.velocityFps, required this.energyFtLb, required this.timeOfFlightSec, required this.mach});
}

abstract interface class BallisticsEngine {
  String get engineName;
  String get engineVersion;
  Future<List<BallisticPoint>> solve(BallisticRequest request);
}

class BallisticsEngineUnavailable implements BallisticsEngine {
  @override String get engineName => 'Validated engine unavailable';
  @override String get engineVersion => '0';
  @override Future<List<BallisticPoint>> solve(BallisticRequest request) =>
      Future.error(StateError('APEX will not generate field DOPE without the validated external ballistics engine.'));
}
