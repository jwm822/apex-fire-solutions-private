// Alpha 0.4 validation policy.
//
// The integration test suite must compare identical-input engine output against
// untouched external reference fixtures and separately against immutable live-
// fire observations. Physics constants must never be tuned to make a fixture
// pass.
//
// Profile #001: Jess reference export.
// Profile #002: Landon, separate profile; AB solution corroborated by live fire
// through 605 yd. Exact observed values must be entered from source records,
// never inferred from the AB table.
// Profile #003: professional 6.5 Creedmoor reference export; preserve CDM/custom
// drag provenance and do not substitute G1/G7 merely to create a comparison.
void main() {}
