# APEX Fire Solutions — Alpha 0.4 Foundation

APEX is a mobile-first shooting data platform. Its product goal is to make established exterior-ballistics science easier to use while adding deeper profile, verification, reloading, range-session, target-analysis, and field-data workflows.

## Non-negotiable engineering rule
APEX does **not** invent or tune ballistic physics to match a desired answer. Production trajectory calculations must be delegated through `BallisticsEngine` to a mature, validated external engine (Ballistics Lab is the integration target). There is intentionally no approximate fallback solver. If the validated engine is unavailable, calculation fails closed.

## Alpha 0.4 scope
- Isolated rifle/configuration/load profiles
- Ballistics-engine adapter boundary
- Quick Solve and drop-table contracts
- Arbitrary-distance verification
- Predicted / reference / field-verified / trued-prediction provenance
- Environment and MV-temperature observations
- Gyroscopic stability / Twist Explorer model contracts
- Range-session records
- Factory-ammo and handload records
- Brass-lot and chronograph history
- Target/group-analysis records
- Configuration fingerprints and lifecycle history
- Red-shift Night Mode requirements
- Regression fixtures for reference datasets

## Reference data
`assets/reference/` contains untouched source exports used for regression/audit. Do not edit them to make tests pass.

Landon's rifle is a separate Profile #002. Its AB solution has been corroborated by live fire through 605 yd. Field observations must be entered as immutable observations when the exact values are available; they must never be inferred from the AB table.

## Next integration milestone
Wire a supported Ballistics Lab binding into `BallisticsEngine`, then run identical-input comparisons against reference fixtures before enabling a `VALIDATED` field-use badge.
