# Architecture

## Layers
1. **External ballistic core** — established physics implementation.
2. **BallisticsEngine adapter** — APEX-owned translation boundary. No competing physics implementation.
3. **Domain** — profiles, configurations, loads, environments, observations, sessions, targets.
4. **Validation/provenance** — comparison and immutable evidence.
5. **Features** — Quick Solve, DOPE, Profiles, Range, Loads, Targets, Tools.
6. **Presentation** — mobile-first progressive-complexity UI.

## Fail-closed calculation policy
If the validated engine cannot calculate a requested solution, APEX returns an explicit unavailable/error state. It must never fall back to a simplified approximation that could look plausible in the field.

## Engine portability
Keep the domain independent of the engine binding so the same external physics core can be exposed through appropriate web/mobile bindings without changing APEX data semantics.

## Provenance
Every computed point carries engine name/version and a SolutionSnapshot ID. Every field observation is stored independently. Truing produces a new model result and does not mutate evidence.
