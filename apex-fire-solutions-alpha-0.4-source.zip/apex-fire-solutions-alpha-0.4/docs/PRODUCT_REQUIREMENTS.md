# Product requirements

## Design principle: progressive complexity
An average hunter must be able to create a profile and get a drop table without touching advanced controls. Precision shooters and reloaders can expand the same profile into deeper tools. Modes change information density, not the underlying physics or data.

## Main areas
- Solver / Quick Solve
- DOPE & Verification
- Armory / Profiles
- Loads & Reloading
- Range Sessions
- Targets / Group Analysis
- Hunt Mode / Hunt Log
- Analytics
- Devices
- Tools (Stability, Twist Explorer, trajectory visualization, Solver Audit)
- Settings / Night Mode

## Quick Solve
Select profile -> enter exact range -> wind speed/direction -> solution. Hero output is elevation and wind. Advanced data is one tap away: velocity, energy, TOF, Mach, spin drift, Coriolis, aerodynamic jump, environment, MV source, SG, and calculation provenance.

## Profile builder
Projectile: manufacturer/name, drag model G1/G7/custom, BC/drag data, diameter, weight, length.
Rifle: MV, zero, sight height, barrel length, twist and direction.
Optic: MOA/MIL, click value, tracking correction, zero-stop metadata.
Environment: temperature, station pressure, humidity, altitude/DA; avoid hidden/double corrections.
Advanced: shot angle, azimuth, latitude, solver switches.

## MV-temperature
Store unlimited measured temperature/velocity pairs. Preserve raw observations. Solver-facing MV must identify its source as measured, interpolated, extrapolated, or manually supplied. Never silently alter MV.

## Stability / Twist Explorer
Use established stability methodology via a dedicated calculator layer. Inputs include bullet dimensions/mass, MV, twist, and atmosphere. Show current-condition and comparison SG plus twist-rate exploration. Calculation method must be identified.

## DOPE & field verification
Generate regular tables and exact arbitrary ranges. A validation course may contain any measured distances (example: 241, 458, 667, 883, 1060 yd). Preserve:
1. original prediction,
2. external reference (optional),
3. immutable field observation,
4. later trued prediction.
Never overwrite one with another.

## Solver Audit / WHY
Every solution snapshot records the exact profile/configuration/load, MV and source, environment, wind, solver switches, engine name/version, and timestamp. Comparison workflow highlights mismatched inputs between solvers/devices.

## Loads / reloading
Factory and handload modes. Handload data may include bullet/lot, powder/lot/charge, primer/lot, brass/lot, firing count, anneal/trim/sizing history, COAL/CBTO, neck tension and notes. Load versioning prevents a verified recipe from being silently overwritten.

## Chronograph
Link raw shots and summary statistics (average MV, SD, ES) to exact load, environment, ammo temperature and session.

## Range Sessions
Start session with rifle/configuration/load. Attach environment, chronograph, cold-bore state, groups, zero changes, and arbitrary-distance verification. End-session updates are explicit and auditable.

## Target / group analysis
Camera/import workflow with reference calibration, POA and impact marking. Calculate extreme spread, inches/cm, MOA/MIL, mean radius, CEP, group center/POI offset, horizontal/vertical dispersion and combined groups. Future automatic impact detection must always be manually correctable.

## Lifecycle / configuration fingerprint
Track barrel round count, maintenance, zero history, cold-bore observations, suppressor/configuration changes. Verified DOPE belongs to an exact configuration fingerprint; material changes trigger a reconfirmation warning.

## Field UX
Offline-first. Range Mode can keep the screen awake. Red-shift Night Mode uses near-black/red surfaces, adjustable brightness, no accidental bright dialogs, and optional Night Lock. Large touch targets and large primary solution.
