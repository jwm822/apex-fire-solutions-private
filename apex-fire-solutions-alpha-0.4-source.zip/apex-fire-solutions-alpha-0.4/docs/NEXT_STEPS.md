# Next steps

1. Add the supported Ballistics Lab mobile binding/package and implement `BallisticsEngine` as a thin adapter.
2. Create regression parsers for the untouched AB reference CSVs.
3. Enter Landon's exact Profile #002 inputs and exact live-fire observations through 605 yd from source records.
4. Gate field-use UI behind regression status; never display a VALIDATED badge merely because a table rendered.
5. Build the first Flutter screens: Profiles, Quick Solve, DOPE/Verification, Range Session, Night Mode.
6. Add persistence and export/import before expanding device integrations.
7. Add MV-temp and stability tools using established formulas/libraries with method/source labels.
8. Add load/brass/chronograph and target-analysis workflows.
